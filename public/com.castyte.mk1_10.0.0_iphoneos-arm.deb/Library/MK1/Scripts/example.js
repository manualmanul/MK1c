confirm("Welcome to MK1!", "This is the example MK1 Script. Would you like to open the MK1 documentation in Filza?", c => {
	if(c) openURL("filza://view/Library/MK1/DOCS.md");
});